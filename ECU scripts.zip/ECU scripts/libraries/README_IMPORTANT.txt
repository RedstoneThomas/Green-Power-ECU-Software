These libraries may not contain all the nececary files.
IF you wish to edit the code, you will almost certainly need to install these in order for it to compile
It is reconmended to install the same files through the arduino IDE, ensuring you download the same named file, by the same author